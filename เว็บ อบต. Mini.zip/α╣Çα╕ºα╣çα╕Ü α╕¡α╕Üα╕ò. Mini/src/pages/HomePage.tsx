import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Building2,
  Phone,
  Mail,
  Clock,
  Calendar,
  FileText,
  Users2,
  Landmark,
  TreePine,
  Menu,
  X,
  Search,
  Home,
  Info,
  Newspaper,
  HandHeart,
  MessageCircle,
  UserCircle,
  Camera,
  MapPin,
  Users,
  Star,
  ShoppingBag,
  LayoutDashboard,
} from "lucide-react";
import OrderModal from "../components/OrderModal";

function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const operationalNews = [
    {
      title: "ประชุมประชาคมพัฒนาชุมชนประจำปี 2568",
      description: "นายกสมชาย ใจดี นำทีมผู้บริหารและเจ้าหน้าที่ลงพื้นที่รับฟังความคิดเห็นและความต้องการของประชาชน เพื่อจัดทำแผนพัฒนาท้องถิ่นที่ตรงความต้องการของชุมชน",
      date: "7 มีนาคม 2568",
      image: "https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?auto=format&fit=crop&w=800&q=80",
      location: "ห้องประชุม อบต.สุขสันต์หรรษา"
    },
    {
      title: "ประชุมคณะผู้บริหารประจำเดือนมีนาคม",
      description: "การประชุมหารือแนวทางการพัฒนาท้องถิ่นและติดตามความคืบหน้าโครงการสำคัญ พร้อมวางแผนการดำเนินงานในไตรมาสถัดไป",
      date: "5 มีนาคม 2568",
      image: "https://images.unsplash.com/photo-1552581234-26160f608093?auto=format&fit=crop&w=800&q=80",
      location: "ห้องประชุมใหญ่"
    },
    {
      title: "โครงการอนุรักษ์สิ่งแวดล้อมชุมชน",
      description: "กิจกรรมปลูกต้นไม้และทำความสะอาดพื้นที่สาธารณะ โดยได้รับความร่วมมือจากประชาชนในพื้นที่กว่า 200 คน",
      date: "3 มีนาคม 2568",
      image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80",
      location: "สวนสาธารณะชุมชน"
    },
    {
      title: "มอบทุนการศึกษาแก่เยาวชนในชุมชน",
      description: "พิธีมอบทุนการศึกษาประจำปี 2568 แก่นักเรียนที่มีผลการเรียนดีแต่ขาดแคลนทุนทรัพย์ จำนวน 50 ทุน",
      date: "1 มีนาคม 2568",
      image: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80",
      location: "หอประชุม อบต."
    },
    {
      title: "ตรวจเยี่ยมโครงการก่อสร้างถนน",
      description: "คณะผู้บริหารลงพื้นที่ตรวจความคืบหน้าโครงการก่อสร้างถนนคอนกรีตเสริมเหล็ก เพื่อให้การดำเนินงานเป็นไปตามมาตรฐาน",
      date: "28 กุมภาพันธ์ 2568",
      image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80",
      location: "หมู่ 3 ตำบลสุขสันต์หรรษา"
    },
    {
      title: "ประชุมคณะกรรมการชมรมผู้สูงอายุ",
      description: "การประชุมวางแผนกิจกรรมและโครงการสำหรับผู้สูงอายุในชุมชน พร้อมรับฟังข้อเสนอแนะเพื่อพัฒนาคุณภาพชีวิต",
      date: "25 กุมภาพันธ์ 2568",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80",
      location: "ศูนย์พัฒนาคุณภาพชีวิตผู้สูงอายุ"
    }
  ];

  const localProducts = [
    {
      name: "ผ้าทอมือลายดอกพิกุล",
      category: "หัตถกรรม",
      price: "890",
      rating: 4.8,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1606297199333-e93f7d726cab?auto=format&fit=crop&w=800&q=80",
      producer: "กลุ่มทอผ้าบ้านสุขสันต์",
      awards: ["OTOP 5 ดาว", "รางวัลหัตถศิลป์ยอดเยี่ยม 2567"]
    },
    {
      name: "น้ำพริกปลาทูสมุนไพร",
      category: "อาหาร",
      price: "120",
      rating: 4.9,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?auto=format&fit=crop&w=800&q=80",
      producer: "วิสาหกิจชุมชนแม่บ้านเกษตรกร",
      awards: ["OTOP 4 ดาว", "รางวัลอาหารปลอดภัย 2567"]
    },
    {
      name: "กระเป๋าสานจากต้นกก",
      category: "หัตถกรรม",
      price: "450",
      rating: 4.7,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80",
      producer: "กลุ่มจักสานบ้านริมน้ำ",
      awards: ["OTOP 4 ดาว"]
    },
    {
      name: "น้ำผึ้งดอกลำไย",
      category: "อาหาร",
      price: "280",
      rating: 5.0,
      reviews: 167,
      image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=800&q=80",
      producer: "กลุ่มเกษตรอินทรีย์",
      awards: ["OTOP 5 ดาว", "รางวัลเกษตรอินทรีย์ดีเด่น"]
    }
  ];

  const handleOrderClick = (product) => {
    setSelectedProduct(product);
    setIsOrderModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-900 text-white">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Landmark size={40} />
              <div>
                <h1 className="text-xl font-semibold">
                  องค์การบริหารส่วนตำบลสุขสันต์หรรษา
                </h1>
                <p className="text-sm">
                  Suksanhasun Subdistrict Administrative Organization
                </p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Phone size={16} />
                <span>02-123-4567</span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="ค้นหา..."
                  className="pl-8 pr-4 py-1 rounded text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
              </div>
            </div>
            <button
              className="md:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4">
          <div className={`${isMenuOpen ? "block" : "hidden"} md:block`}>
            <ul className="md:flex md:space-x-1">
              <NavItem to="/" icon={<Home size={18} />} text="หน้าหลัก" />
              <NavItem
                to="/about"
                icon={<Info size={18} />}
                text="เกี่ยวกับเรา"
              />
              <NavItem
                to="/services"
                icon={<FileText size={18} />}
                text="บริการประชาชน"
              />
                 <NavItem
                to="/dashboard"
                icon={<LayoutDashboard size={18} />}
                text="สรุปผลการดำเนินงาน"
              />
              
              <NavItem
                to="/news"
                icon={<Newspaper size={18} />}
                text="ข่าวสาร"
              />
              <NavItem
                to="/community"
                icon={<HandHeart size={18} />}
                text="พัฒนาชุมชน"
              />
              <NavItem
                to="/contact"
                icon={<MessageCircle size={18} />}
                text="ติดต่อเรา"
              />
              <NavItem
                to="/staff"
                icon={<UserCircle size={18} />}
                text="บุคลากร"
              />
                 <NavItem
                to="/documents"
                icon={<Newspaper size={18} />}
                text="ดาวโหลดเอกสาร"
              />
           
            </ul>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-[400px]">
        <img
          src="https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&w=1920&q=80"
          alt="Temple in Thailand"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-4xl font-bold mb-4 text-shadow-lg">
              ยินดีต้อนรับสู่ อบต.สุขสันต์หรรษา
            </h2>
            <p className="text-xl text-shadow">
              บริการประชาชนด้วยใจ พัฒนาท้องถิ่นอย่างยั่งยืน
            </p>
          </div>
        </div>
      </div>

      {/* News Ticker */}
      <div className="bg-primary-50 py-2 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex items-center">
            <span className="bg-primary-600 text-white px-4 py-1 rounded-full text-sm font-semibold mr-4">
              ข่าวด่วน
            </span>
            <div className="overflow-hidden flex-1">
              <div className="whitespace-nowrap animate-ticker">
                <span className="inline-block px-4">
                  📢 ประกาศรับสมัครงาน ตำแหน่งนักวิชาการสาธารณสุข
                </span>
                <span className="inline-block px-4">
                  🎓 เปิดรับสมัครทุนการศึกษาประจำปี 2567
                </span>
                <span className="inline-block px-4">
                  📋 ประชาสัมพันธ์การชำระภาษีที่ดินและสิ่งปลูกสร้าง
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Links */}
      <div className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link to="/tax-payment">
              <QuickLink
                icon={<FileText className="w-6 h-6" />}
                title="ชำระภาษี"
                description="ชำระภาษีออนไลน์"
              />
            </Link>
            <Link to="/complaint">
              <QuickLink
                icon={<Users2 className="w-6 h-6" />}
                title="ร้องเรียน"
                description="แจ้งเรื่องร้องเรียน"
              />
            </Link>
            <Link to="/welfare">
              <QuickLink
                icon={<HandHeart className="w-6 h-6" />}
                title="สวัสดิการ"
                description="ลงทะเบียนสวัสดิการ"
              />
            </Link>
            <Link to="/contact">
              <QuickLink
                icon={<MessageCircle className="w-6 h-6" />}
                title="ติดต่อ"
                description="ติดต่อเจ้าหน้าที่"
              />
            </Link>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">บริการของเรา</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <ServiceCard
            icon={<FileText className="w-8 h-8" />}
            title="บริการออนไลน์"
            description="ยื่นคำร้อง ชำระภาษี และบริการอื่นๆ ผ่านระบบออนไลน์"
          />
          <ServiceCard
            icon={<Users2 className="w-8 h-8" />}
            title="สวัสดิการสังคม"
            description="การดูแลผู้สูงอายุ ผู้พิการ และผู้ด้อยโอกาส"
          />
          <ServiceCard
            icon={<TreePine className="w-8 h-8" />}
            title="สิ่งแวดล้อม"
            description="การจัดการขยะ และการรักษาสิ่งแวดล้อมในชุมชน"
          />
        </div>
      </div>

      {/* OTOP Products Section */}
      <div className="bg-gradient-to-b from-white to-primary-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">ผลิตภัณฑ์ชุมชน OTOP</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              ผลิตภัณฑ์คุณภาพจากภูมิปัญญาท้องถิ่น สร้างรายได้สู่ชุมชน
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {localProducts.map((product, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="relative">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <div className="bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-sm font-semibold shadow-lg">
                      {product.awards[0]}
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="text-sm text-primary-600 font-medium mb-2">
                    {product.category}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {product.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    ผลิตโดย: {product.producer}
                  </p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-gray-600">
                        {product.rating} ({product.reviews} รีวิว)
                      </span>
                    </div>
                    <span className="text-xl font-bold text-primary-600">
                      ฿{product.price}
                    </span>
                  </div>
                  <button
                    onClick={() => handleOrderClick(product)}
                    className="w-full bg-primary-600 text-white py-2 rounded-lg hover:bg-primary-700 transition-colors flex items-center justify-center"
                  >
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    สั่งซื้อสินค้า
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="inline-flex items-center px-6 py-3 border-2 border-primary-600 text-primary-600 font-semibold rounded-lg hover:bg-primary-600 hover:text-white transition-colors">
              ดูสินค้าทั้งหมด
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Operational News Section */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">ภาพข่าวปฏิบัติงาน</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {operationalNews.map((news, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="relative">
                  <img 
                    src={news.image} 
                    alt={news.title} 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                    <div className="flex items-center text-white text-sm">
                      <Calendar className="w-4 h-4 mr-2" />
                      {news.date}
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 text-gray-900 line-clamp-2">
                    {news.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {news.description}
                  </p>
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <MapPin className="w-4 h-4 mr-2" />
                    {news.location}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center text-sm text-gray-500">
                      <Camera className="w-4 h-4 mr-2" />
                      <span>ดูภาพทั้งหมด</span>
                    </div>
                    <button className="text-blue-600 hover:text-blue-700 font-semibold text-sm">
                      อ่านเพิ่มเติม →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-blue-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">ติดต่อเรา</h3>
              <div className="space-y-2">
                <p className="flex items-center">
                  <Building2 className="w-4 h-4 mr-2" /> อบต.สุขสันต์หรรษา
                </p>
                <p className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" /> 02-123-4567
                </p>
                <p className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" /> info@suksanhasun.go.th
                </p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">เวลาทำการ</h3>
              <div className="space-y-2">
                <p className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" /> จันทร์ - ศุกร์
                </p>
                <p className="ml-6">8:30 - 16:30 น.</p>
                <p className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" /> หยุดวันเสาร์-อาทิตย์
                  และวันหยุดนักขัตฤกษ์
                </p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">ลิงก์ที่เกี่ยวข้อง</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/about" className="hover:text-blue-200">
                    เกี่ยวกับ อบต.
                  </Link>
                </li>
                <li>
                  <Link to="/services" className="hover:text-blue-200">
                    แผนพัฒนาท้องถิ่น
                  </Link>
                </li>
                <li>
                  <Link to="/services" className="hover:text-blue-200">
                    จัดซื้อจัดจ้าง
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="hover:text-blue-200">
                    ติดต่อเรา
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">เว็บไซต์ที่เกี่ยวข้อง</h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="https://www.dla.go.th"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-blue-200"
                  >
                    กรมส่งเสริมการปกครองท้องถิ่น
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.moi.go.th"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-blue-200"
                  >
                    กระทรวงมหาดไทย
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.thaigov.go.th"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-blue-200"
                  >
                    รัฐบาลไทย
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-blue-800 text-center">
            <p>© 2567 องค์การบริหารส่วนตำบลสุขสันต์หรรษา. สงวนลิขสิทธิ์.</p>
          </div>
        </div>
      </footer>

      {/* Order Modal */}
      {selectedProduct && (
        <OrderModal
          isOpen={isOrderModalOpen}
          onClose={() => {
            setIsOrderModalOpen(false);
            setSelectedProduct(null);
          }}
          product={selectedProduct}
        />
      )}
    </div>
  );
}

function NavItem({ icon, text, to }) {
  return (
    <li>
      <Link
        to={to}
        className="flex items-center space-x-2 px-4 py-3 hover:bg-blue-700"
      >
        {icon}
        <span>{text}</span>
      </Link>
    </li>
  );
}

function QuickLink({ icon, title, description }) {
  return (
    <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
      <div className="text-blue-900">{icon}</div>
      <div>
        <h3 className="font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </div>
  );
}

function ServiceCard({ icon, title, description }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow">
      <div className="inline-block p-3 bg-blue-100 rounded-full text-blue-900 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export default HomePage;