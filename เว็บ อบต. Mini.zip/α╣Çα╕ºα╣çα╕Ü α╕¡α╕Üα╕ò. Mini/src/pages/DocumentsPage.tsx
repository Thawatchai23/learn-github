import React, { useState } from 'react';
import { ArrowLeft, Search, FileText, Download, Printer, ChevronDown, Filter, Eye, Calendar, FileIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

const documents = [
  {
    id: 'DOC001',
    title: 'แบบคำร้องทั่วไป',
    category: 'แบบฟอร์มคำร้อง',
    format: 'PDF',
    size: '250 KB',
    lastUpdated: '15 มีนาคม 2567',
    downloads: 156,
    url: '/documents/general-request-form.pdf'
  },
  {
    id: 'DOC002',
    title: 'แบบยื่นขออนุญาตก่อสร้างอาคาร',
    category: 'กองช่าง',
    format: 'PDF',
    size: '500 KB',
    lastUpdated: '10 มีนาคม 2567',
    downloads: 89,
    url: '/documents/construction-permit-form.pdf'
  },
  {
    id: 'DOC003',
    title: 'แบบลงทะเบียนผู้สูงอายุ',
    category: 'สวัสดิการสังคม',
    format: 'PDF',
    size: '300 KB',
    lastUpdated: '8 มีนาคม 2567',
    downloads: 234,
    url: '/documents/elderly-registration-form.pdf'
  },
  {
    id: 'DOC004',
    title: 'แบบคำร้องขอจดทะเบียนพาณิชย์',
    category: 'ทะเบียนพาณิชย์',
    format: 'PDF',
    size: '400 KB',
    lastUpdated: '5 มีนาคม 2567',
    downloads: 123,
    url: '/documents/commercial-registration-form.pdf'
  },
  {
    id: 'DOC005',
    title: 'แบบยื่นชำระภาษีที่ดินและสิ่งปลูกสร้าง',
    category: 'กองคลัง',
    format: 'PDF',
    size: '350 KB',
    lastUpdated: '1 มีนาคม 2567',
    downloads: 178,
    url: '/documents/property-tax-form.pdf'
  }
];

const categories = [
  'ทั้งหมด',
  'แบบฟอร์มคำร้อง',
  'กองช่าง',
  'สวัสดิการสังคม',
  'ทะเบียนพาณิชย์',
  'กองคลัง'
];

export default function DocumentsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ทั้งหมด');
  const [sortBy, setSortBy] = useState('date');

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'ทั้งหมด' || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedDocuments = [...filteredDocuments].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.title.localeCompare(b.title);
      case 'downloads':
        return b.downloads - a.downloads;
      case 'date':
      default:
        return new Date(b.lastUpdated) - new Date(a.lastUpdated);
    }
  });

  const handleDownload = (doc) => {
    // In a real application, this would trigger the actual download
    console.log('Downloading:', doc.title);
    alert('เริ่มดาวน์โหลดเอกสาร: ' + doc.title);
  };

  const handlePrint = (doc) => {
    // In a real application, this would open the print dialog
    console.log('Printing:', doc.title);
    alert('กำลังเปิดหน้าต่างพิมพ์เอกสาร: ' + doc.title);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-8">
      <div className="container mx-auto px-4">
        <Link to="/" className="inline-flex items-center text-blue-700 hover:text-blue-600 mb-6">
          <ArrowLeft className="w-5 h-5 mr-2" />
          กลับหน้าหลัก
        </Link>

        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">ดาวน์โหลดเอกสาร</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              ดาวน์โหลดแบบฟอร์ม เอกสารราชการ และแบบคำร้องต่างๆ สำหรับติดต่อราชการกับ อบต.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="ค้นหาเอกสาร..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
            <div className="flex gap-4">
              <div className="relative">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="appearance-none bg-white pl-4 pr-10 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {categories.map(category => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
              </div>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none bg-white pl-4 pr-10 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="date">เรียงตามวันที่</option>
                  <option value="name">เรียงตามชื่อ</option>
                  <option value="downloads">เรียงตามยอดดาวน์โหลด</option>
                </select>
                <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Documents List */}
          <div className="space-y-4">
            {sortedDocuments.map((doc) => (
              <div
                key={doc.id}
                className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{doc.title}</h3>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center">
                          <FileIcon className="w-4 h-4 mr-1" />
                          {doc.format} • {doc.size}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {doc.lastUpdated}
                        </span>
                        <span className="flex items-center">
                          <Download className="w-4 h-4 mr-1" />
                          {doc.downloads} ดาวน์โหลด
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-4 md:mt-0">
                    <button
                      onClick={() => handlePrint(doc)}
                      className="flex items-center px-3 py-1 text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      <Printer className="w-4 h-4 mr-1" />
                      <span>พิมพ์</span>
                    </button>
                    <button
                      onClick={() => handleDownload(doc)}
                      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      <span>ดาวน์โหลด</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Help Section */}
          <div className="mt-8 bg-blue-50 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-blue-900 mb-4">วิธีการดาวน์โหลดและพิมพ์เอกสาร</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">การดาวน์โหลด</h3>
                <ol className="list-decimal list-inside space-y-2 text-gray-600">
                  <li>ค้นหาเอกสารที่ต้องการ</li>
                  <li>คลิกปุ่ม "ดาวน์โหลด"</li>
                  <li>เลือกตำแหน่งที่ต้องการบันทึกไฟล์</li>
                  <li>เปิดไฟล์ด้วยโปรแกรม PDF Reader</li>
                </ol>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">การพิมพ์</h3>
                <ol className="list-decimal list-inside space-y-2 text-gray-600">
                  <li>คลิกปุ่ม "พิมพ์"</li>
                  <li>ตั้งค่าการพิมพ์ตามต้องการ</li>
                  <li>ตรวจสอบการตั้งค่าหน้ากระดาษ</li>
                  <li>คลิกพิมพ์เอกสาร</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}